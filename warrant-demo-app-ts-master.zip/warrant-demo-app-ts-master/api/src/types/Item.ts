export default interface Item {
    id: number;
    storeId: number;
    name: string;
    description: string;
    price: number;
}
