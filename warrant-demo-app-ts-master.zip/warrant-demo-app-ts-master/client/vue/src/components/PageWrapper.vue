<template>
<div class="page-wrapper">
    <slot></slot>
</div>
</template>

<style>
.page-wrapper {
    margin: auto;
}

.page-title {
    text-align: center;
}
</style>
