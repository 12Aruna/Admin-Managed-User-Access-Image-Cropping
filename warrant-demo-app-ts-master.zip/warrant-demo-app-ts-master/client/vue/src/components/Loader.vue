<template>
<div class="loader">Loading...</div>
</template>

<style>
.loader {
    margin: auto;
    text-align: center;
}
</style>
