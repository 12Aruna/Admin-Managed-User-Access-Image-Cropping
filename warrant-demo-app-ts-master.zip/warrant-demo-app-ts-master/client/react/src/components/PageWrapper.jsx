import styled from "styled-components";

const PageWrapper = styled.div`
    margin: auto;
`;

export default PageWrapper;
